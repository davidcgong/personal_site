export { default } from './Share';
