export { default } from './Pagination';
