export { default } from './Copyright';
