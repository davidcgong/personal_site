'use strict';

require('./src/assets/scss/init.scss');

exports.onClientEntry = () => {};
