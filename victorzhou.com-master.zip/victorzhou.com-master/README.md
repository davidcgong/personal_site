# victorzhou.com

[![Build Status](https://travis-ci.com/vzhou842/victorzhou.com.svg?branch=master)](https://travis-ci.com/vzhou842/victorzhou.com)

This is a site built with [Gatsby.js](https://www.gatsbyjs.org/). To get started:

```bash
npm install
npm run develop
```
