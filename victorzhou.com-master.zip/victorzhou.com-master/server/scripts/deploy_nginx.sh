sudo cp ./server/nginx/nginx.conf /etc/nginx.conf
sudo service nginx restart
